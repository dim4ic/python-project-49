### Hexlet tests and linter status:
[![Actions Status](https://github.com/dim4ic/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/dim4ic/python-project-49/actions)