### Hexlet tests and linter status:
[![Actions Status](https://github.com/dim4ic/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/dim4ic/python-project-49/actions)
<a href="https://codeclimate.com/github/dim4ic/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/23baf5be06f7f9665f9a/maintainability" /></a>

### brain-even  
https://asciinema.org/a/Fbz9tyhTw1ncpmJz2lVl06BkV

### brain-calc
https://asciinema.org/a/1yOSuuzxPhKVwuS7tXEsn6RRv

### brain-gcd
https://asciinema.org/a/0Mu7ODRjtOFlmS2U2KxSlHylU

### brain-progression
https://asciinema.org/a/wjSRhi7XSJN80q0wFCrryziQt

### brain-prime
https://asciinema.org/a/5IG6y6NowPfvTaLTb7mrJs7PZ

